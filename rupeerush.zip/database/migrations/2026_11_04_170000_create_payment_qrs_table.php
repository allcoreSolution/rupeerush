<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payment_qrs', function (Blueprint $table) {
            $table->id();
            $table->string('platform', 50)->default('other');
            $table->string('platform_name', 100);
            $table->string('upi_id', 150)->nullable();
            $table->string('upi_name', 150)->nullable();
            $table->string('qr_code_path', 255);
            $table->boolean('is_active')->default(true);
            $table->integer('display_order')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payment_qrs');
    }
};
