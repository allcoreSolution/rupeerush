<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('page_title', 'Dashboard & Business Overview'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    @media (min-width: 1400px) {
        .row-cols-xxl-6 > * {
            flex: 0 0 auto;
            width: 16.666667%;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- TOP 12 KPI STAT CARDS (ALL EQUAL PROPORTIONS & SIZES) -->
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xxl-6 g-3 mb-4">
    <!-- 1. Total Players -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid #0284c7 !important;">
            <div class="rounded-circle d-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary mb-2" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-users fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Total Players</div>
                <div class="fs-4 fw-bold text-dark mt-1"><?php echo e(number_format($totalUsers)); ?></div>
                <small class="text-success fw-semibold"><i class="fa-solid fa-circle-dot me-1"></i><?php echo e($activeUsers); ?> Active</small>
            </div>
        </div>
    </div>

    <!-- 2. Wallet Exposure -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid #0ea5e9 !important;">
            <div class="rounded-circle d-flex align-items-center justify-content-center bg-info bg-opacity-10 text-info mb-2" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-wallet fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Wallet Exposure</div>
                <div class="fs-4 fw-bold text-primary mt-1 font-monospace">₹<?php echo e(number_format($totalUserBalances, 2)); ?></div>
                <small class="text-muted">Total in player wallets</small>
            </div>
        </div>
    </div>

    <!-- 3. Total Deposits -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid #10b981 !important;">
            <div class="rounded-circle d-flex align-items-center justify-content-center bg-success bg-opacity-10 text-success mb-2" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-circle-arrow-down fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Total Deposits</div>
                <div class="fs-4 fw-bold text-success mt-1 font-monospace">₹<?php echo e(number_format($totalDeposits, 2)); ?></div>
                <small class="text-success"><i class="fa-solid fa-check me-1"></i><?php echo e($approvedDepositsCount); ?> Approved</small>
            </div>
        </div>
    </div>

    <!-- 4. Pending Deposits -->
    <div class="col">
        <a href="<?php echo e(route('admin.payments.deposits')); ?>" class="text-decoration-none text-dark">
            <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid <?php echo e($pendingDepositsCount > 0 ? '#ef4444' : '#cbd5e1'); ?> !important;">
                <div class="rounded-circle d-flex align-items-center justify-content-center mb-2 <?php echo e($pendingDepositsCount > 0 ? 'bg-danger bg-opacity-10 text-danger' : 'bg-light text-muted'); ?>" style="width: 40px; height: 40px;">
                    <i class="fa-solid fa-money-bill-transfer fs-5"></i>
                </div>
                <div>
                    <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Pending Deposits</div>
                    <div class="fs-4 fw-bold mt-1 font-monospace <?php echo e($pendingDepositsCount > 0 ? 'text-danger' : 'text-dark'); ?>">
                        <?php echo e($pendingDepositsCount); ?>

                    </div>
                    <small class="<?php echo e($pendingDepositsCount > 0 ? 'text-danger fw-bold' : 'text-muted'); ?>">
                        ₹<?php echo e(number_format($pendingDepositsAmount, 2)); ?> <?php echo e($pendingDepositsCount > 0 ? 'waiting' : 'pending'); ?>

                    </small>
                </div>
            </div>
        </a>
    </div>

    <!-- 5. Total Withdrawals -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid #f59e0b !important;">
            <div class="rounded-circle d-flex align-items-center justify-content-center bg-warning bg-opacity-10 text-warning mb-2" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-arrow-up-from-bracket fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Total Withdrawals</div>
                <div class="fs-4 fw-bold text-dark mt-1 font-monospace">₹<?php echo e(number_format($totalWithdrawals, 2)); ?></div>
                <small class="text-muted"><?php echo e($settledWithdrawalsCount); ?> Settled Payouts</small>
            </div>
        </div>
    </div>

    <!-- 6. Pending Withdrawals -->
    <div class="col">
        <a href="<?php echo e(route('admin.payments.withdrawals')); ?>" class="text-decoration-none text-dark">
            <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid <?php echo e($pendingWithdrawalsCount > 0 ? '#f59e0b' : '#cbd5e1'); ?> !important;">
                <div class="rounded-circle d-flex align-items-center justify-content-center mb-2 <?php echo e($pendingWithdrawalsCount > 0 ? 'bg-warning bg-opacity-10 text-warning' : 'bg-light text-muted'); ?>" style="width: 40px; height: 40px;">
                    <i class="fa-solid fa-clock fs-5"></i>
                </div>
                <div>
                    <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Pending Withdrawals</div>
                    <div class="fs-4 fw-bold mt-1 font-monospace <?php echo e($pendingWithdrawalsCount > 0 ? 'text-warning text-dark' : 'text-dark'); ?>">
                        <?php echo e($pendingWithdrawalsCount); ?>

                    </div>
                    <small class="<?php echo e($pendingWithdrawalsCount > 0 ? 'text-danger fw-bold' : 'text-muted'); ?>">
                        ₹<?php echo e(number_format($pendingWithdrawalsAmount, 2)); ?> <?php echo e($pendingWithdrawalsCount > 0 ? 'to pay' : 'pending'); ?>

                    </small>
                </div>
            </div>
        </a>
    </div>

    <!-- 7. Adjusted Balance -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid #7c3aed !important;">
            <div class="rounded-circle d-flex align-items-center justify-content-center mb-2" style="width: 40px; height: 40px; background: rgba(124, 58, 237, 0.12); color: #7c3aed;">
                <i class="fa-solid fa-sliders fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem; color: #7c3aed !important;">Adjusted Balance</div>
                <div class="fs-4 fw-bold mt-1 font-monospace" style="color: #7c3aed;">
                    <?php echo e($netAdjusted >= 0 ? '+' : ''); ?>₹<?php echo e(number_format($netAdjusted, 2)); ?>

                </div>
                <small class="text-muted" style="font-size: 0.72rem;">
                    +₹<?php echo e(number_format($adjustedCredits, 0)); ?> Cr | -₹<?php echo e(number_format($adjustedDebits, 0)); ?> Dr
                </small>
            </div>
        </div>
    </div>

    <!-- 8. Total Bets Wagered -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid #64748b !important;">
            <div class="rounded-circle d-flex align-items-center justify-content-center bg-secondary bg-opacity-10 text-secondary mb-2" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-coins fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Total Bets Wagered</div>
                <div class="fs-4 fw-bold text-dark mt-1 font-monospace">₹<?php echo e(number_format($totalBets, 2)); ?></div>
                <small class="text-muted"><?php echo e($totalBetsCount); ?> Total Bets Placed</small>
            </div>
        </div>
    </div>

    <!-- 9. Total Won (Payouts) -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid #059669 !important;">
            <div class="rounded-circle d-flex align-items-center justify-content-center bg-success bg-opacity-10 text-success mb-2" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-trophy fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Total Won (Payouts)</div>
                <div class="fs-4 fw-bold text-success mt-1 font-monospace">₹<?php echo e(number_format($totalWon, 2)); ?></div>
                <small class="text-success fw-semibold"><?php echo e($totalWonCount); ?> Winning Bets</small>
            </div>
        </div>
    </div>

    <!-- 10. Platform GGR -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="<?php echo e($netGgr >= 0 ? 'border-left: 4px solid #10b981 !important;' : 'border-left: 4px solid #ef4444 !important;'); ?>">
            <div class="rounded-circle d-flex align-items-center justify-content-center mb-2 <?php echo e($netGgr >= 0 ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger'); ?>" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-chart-line fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Platform GGR</div>
                <div class="fs-4 fw-bold <?php echo e($netGgr >= 0 ? 'text-success' : 'text-danger'); ?> mt-1 font-monospace">
                    <?php echo e($netGgr >= 0 ? '+' : ''); ?>₹<?php echo e(number_format($netGgr, 2)); ?>

                </div>
                <small class="<?php echo e($netGgr >= 0 ? 'text-success' : 'text-danger'); ?> fw-semibold" style="font-size: 0.72rem;">
                    <?php echo e($netGgr >= 0 ? 'House Profit' : 'Player Surplus'); ?>

                </small>
            </div>
        </div>
    </div>

    <!-- 11. Today's Turnover -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="border-left: 4px solid #06b6d4 !important;">
            <div class="rounded-circle d-flex align-items-center justify-content-center bg-info bg-opacity-10 text-info mb-2" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-dice fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Today's Turnover</div>
                <div class="fs-4 fw-bold text-dark mt-1 font-monospace">₹<?php echo e(number_format($todayBetsAmount, 2)); ?></div>
                <small class="text-muted"><?php echo e($todayBetsCount); ?> Bets Today</small>
            </div>
        </div>
    </div>

    <!-- 12. Today's Net Profit / Loss -->
    <div class="col">
        <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white" style="<?php echo e($todayNetProfit >= 0 ? 'border-left: 4px solid #10b981 !important;' : 'border-left: 4px solid #ef4444 !important;'); ?>">
            <div class="rounded-circle d-flex align-items-center justify-content-center mb-2 <?php echo e($todayNetProfit >= 0 ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger'); ?>" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-scale-balanced fs-5"></i>
            </div>
            <div>
                <div class="text-muted small fw-bold text-uppercase" style="font-size: 0.68rem;">Today's Profit / Loss</div>
                <div class="fs-4 fw-bold <?php echo e($todayNetProfit >= 0 ? 'text-success' : 'text-danger'); ?> mt-1 font-monospace">
                    <?php echo e($todayNetProfit >= 0 ? '+' : ''); ?>₹<?php echo e(number_format($todayNetProfit, 2)); ?>

                </div>
                <small class="<?php echo e($todayNetProfit >= 0 ? 'text-success' : 'text-danger'); ?> fw-semibold" style="font-size: 0.72rem;">
                    Won: ₹<?php echo e(number_format($todayPayoutsAmount, 0)); ?>

                </small>
            </div>
        </div>
    </div>
</div>

<!-- LIVE LOTTERY TIMING STATUS BANNER -->
<div class="card-custom mb-4 border-info">
    <div class="card-custom-body bg-light py-3 d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3">
            <span class="badge bg-danger text-white px-3 py-2 rounded-pill fw-bold">
                <i class="fa-solid fa-circle text-white me-1" style="font-size: 8px;"></i> LIVE ENGINE
            </span>
            <div>
                <strong>Next Slot: <?php echo e($timingStatus['nextUpcomingSlot']['slot_time']); ?></strong>
                <span class="text-muted ms-2">(Auto-generates 2 min early at <?php echo e($timingStatus['nextUpcomingSlot']['gen_datetime']->format('h:i A')); ?>)</span>
            </div>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?php echo e(route('admin.results.index')); ?>" class="btn btn-primary btn-sm rounded-pill px-3 fw-bold">
                <i class="fa-solid fa-sliders me-1"></i> Control / Preset Numbers
            </a>
            <form method="POST" action="<?php echo e(route('admin.results.instant-generate')); ?>" onsubmit="return confirm('Instantly generate results and execute payouts for the upcoming slot?');">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-warning btn-sm rounded-pill px-3 fw-bold text-dark">
                    <i class="fa-solid fa-bolt me-1"></i> Instant Generate
                </button>
            </form>
        </div>
    </div>
</div>

<!-- LOWER SECTION 1: RECENT DEPOSITS & RECENT WITHDRAWALS (FROM DATABASE) -->
<div class="row g-4 mb-4">
    <!-- Left Column: Recent Deposit Requests -->
    <div class="col-lg-6">
        <div class="card-custom h-100">
            <div class="card-custom-header">
                <h6 class="card-custom-title">
                    <i class="fa-solid fa-money-bill-transfer text-primary"></i>
                    <span>Recent Deposit Requests</span>
                </h6>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('admin.payments.daily')); ?>" class="btn btn-sm btn-info text-white rounded-pill px-3 fw-bold">
                        <i class="fa-solid fa-calendar-days me-1"></i> Daily Detail
                    </a>
                    <a href="<?php echo e(route('admin.payments.deposits')); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-bold">View All</a>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-muted text-uppercase" style="font-size: 0.72rem;">
                        <tr>
                            <th class="ps-3">Player</th>
                            <th>Amount</th>
                            <th>UTR / Ref</th>
                            <th>Status</th>
                            <th class="pe-3 text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentDeposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark">
                                        <?php if($dep->user): ?>
                                            <a href="<?php echo e(route('admin.ledger.show', $dep->user->id)); ?>" class="text-decoration-none text-dark hover-primary">
                                                <?php echo e($dep->user->name); ?>

                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">User #<?php echo e($dep->user_id); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <small class="text-muted font-monospace"><?php echo e($dep->user->phone ?? ''); ?></small>
                                </td>
                                <td class="font-monospace fw-bold text-success">+₹<?php echo e(number_format($dep->amount, 2)); ?></td>
                                <td class="font-monospace small text-muted">
                                    <div><?php echo e($dep->utr_number ?: '-'); ?></div>
                                    <?php if($dep->payment_method): ?>
                                        <span class="badge bg-light text-primary border border-primary-subtle rounded-pill font-monospace" style="font-size: 0.65rem;">
                                            <?php echo e($dep->payment_method); ?>

                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($dep->status === 'approved'): ?>
                                        <span class="badge bg-success-subtle text-success px-2 py-1 rounded-pill">Approved</span>
                                    <?php elseif($dep->status === 'rejected'): ?>
                                        <span class="badge bg-danger-subtle text-danger px-2 py-1 rounded-pill">Rejected</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-warning-emphasis px-2 py-1 rounded-pill">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td class="pe-3 text-end">
                                    <?php if($dep->status === 'pending'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.payments.deposits.approve', $dep->id)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-success rounded-pill px-2 py-0 fw-bold" title="Approve Deposit">
                                                <i class="fa-solid fa-check"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('admin.payments.deposits')); ?>?search=<?php echo e($dep->utr_number); ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-2 py-0">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted small">No deposit records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Right Column: Recent Withdrawal Requests -->
    <div class="col-lg-6">
        <div class="card-custom h-100">
            <div class="card-custom-header">
                <h6 class="card-custom-title">
                    <i class="fa-solid fa-arrow-up-from-bracket text-warning"></i>
                    <span>Recent Withdrawal Requests</span>
                </h6>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('admin.payments.withdrawals')); ?>" class="btn btn-sm btn-outline-warning text-dark rounded-pill px-3 fw-bold">View All</a>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-muted text-uppercase" style="font-size: 0.72rem;">
                        <tr>
                            <th class="ps-3">Player</th>
                            <th>Amount</th>
                            <th>Bank / UPI</th>
                            <th>Status</th>
                            <th class="pe-3 text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentWithdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark">
                                        <?php if($wth->user): ?>
                                            <a href="<?php echo e(route('admin.ledger.show', $wth->user->id)); ?>" class="text-decoration-none text-dark hover-primary">
                                                <?php echo e($wth->user->name); ?>

                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">User #<?php echo e($wth->user_id); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <small class="text-muted font-monospace"><?php echo e($wth->user->phone ?? ''); ?></small>
                                </td>
                                <td class="font-monospace fw-bold text-danger">-₹<?php echo e(number_format($wth->amount, 2)); ?></td>
                                <td class="small text-muted font-monospace">
                                    <?php echo e(Str::limit($wth->account_details ?: ($wth->account_number ?: 'UPI/Bank'), 20)); ?>

                                </td>
                                <td>
                                    <?php if(in_array($wth->status, ['approved', 'completed'])): ?>
                                        <span class="badge bg-success-subtle text-success px-2 py-1 rounded-pill">Paid</span>
                                    <?php elseif($wth->status === 'rejected'): ?>
                                        <span class="badge bg-danger-subtle text-danger px-2 py-1 rounded-pill">Rejected</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-warning-emphasis px-2 py-1 rounded-pill">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td class="pe-3 text-end">
                                    <a href="<?php echo e(route('admin.payments.withdrawals')); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-2 py-0">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted small">No withdrawal requests found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- LOWER SECTION 2: LIVE WAGERS ACROSS ALL GAMES & WINNING PAYOUTS -->
<div class="row g-4 mb-4">
    <!-- Left: Live Wagers Placed (All Games) -->
    <div class="col-lg-6">
        <div class="card-custom h-100">
            <div class="card-custom-header">
                <h6 class="card-custom-title">
                    <i class="fa-solid fa-gamepad text-success"></i>
                    <span>Latest Wagers Placed (All Games)</span>
                </h6>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-light text-dark border font-monospace"><?php echo e($totalBetsCount); ?> Total Bets</span>
                    <a href="<?php echo e(route('admin.bets.index')); ?>" class="btn btn-sm btn-outline-success rounded-pill px-3 fw-bold">View Bets</a>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-muted text-uppercase" style="font-size: 0.72rem;">
                        <tr>
                            <th class="ps-3">Player</th>
                            <th>Game & Description</th>
                            <th class="text-end">Bet Amount</th>
                            <th class="pe-3 text-end">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentWagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark">
                                        <?php if($bet->user): ?>
                                            <a href="<?php echo e(route('admin.ledger.show', $bet->user->id)); ?>" class="text-decoration-none text-dark hover-primary">
                                                <?php echo e($bet->user->name); ?>

                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">User #<?php echo e($bet->user_id); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <small class="text-muted font-monospace"><?php echo e($bet->user->phone ?? ''); ?></small>
                                </td>
                                <td>
                                    <div class="small fw-semibold text-dark">
                                        <?php echo e($bet->admin_notes ?: 'Wager Placed'); ?>

                                    </div>
                                    <small class="text-muted font-monospace" style="font-size: 0.68rem;">#TXN-<?php echo e($bet->id); ?></small>
                                </td>
                                <td class="text-end font-monospace fw-bold text-danger">
                                    -₹<?php echo e(number_format($bet->amount, 2)); ?>

                                </td>
                                <td class="pe-3 text-end small text-muted font-monospace">
                                    <?php echo e($bet->created_at?->diffForHumans()); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted small">No wagers recorded yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Right: Recent Winning Payouts -->
    <div class="col-lg-6">
        <div class="card-custom h-100">
            <div class="card-custom-header">
                <h6 class="card-custom-title">
                    <i class="fa-solid fa-trophy text-warning"></i>
                    <span>Latest Winning Payouts</span>
                </h6>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-light text-dark border font-monospace"><?php echo e($totalWonCount); ?> Total Wins</span>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-muted text-uppercase" style="font-size: 0.72rem;">
                        <tr>
                            <th class="ps-3">Player</th>
                            <th>Game & Payout Description</th>
                            <th class="text-end">Won Payout</th>
                            <th class="pe-3 text-end">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentWins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $win): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold text-dark">
                                        <?php if($win->user): ?>
                                            <a href="<?php echo e(route('admin.ledger.show', $win->user->id)); ?>" class="text-decoration-none text-dark hover-primary">
                                                <?php echo e($win->user->name); ?>

                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">User #<?php echo e($win->user_id); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <small class="text-muted font-monospace"><?php echo e($win->user->phone ?? ''); ?></small>
                                </td>
                                <td>
                                    <div class="small fw-semibold text-success">
                                        <?php echo e($win->admin_notes ?: 'Winning Payout Credited'); ?>

                                    </div>
                                    <small class="text-muted font-monospace" style="font-size: 0.68rem;">#TXN-<?php echo e($win->id); ?></small>
                                </td>
                                <td class="text-end font-monospace fw-bold text-success">
                                    +₹<?php echo e(number_format($win->amount, 2)); ?>

                                </td>
                                <td class="pe-3 text-end small text-muted font-monospace">
                                    <?php echo e($win->created_at?->diffForHumans()); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted small">No win payouts recorded yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- LOWER SECTION 3: PLATFORM GAMES PERFORMANCE MATRIX (FETCHED LIVE FROM DATABASE) -->
<div class="card-custom mb-4">
    <div class="card-custom-header">
        <h6 class="card-custom-title">
            <i class="fa-solid fa-layer-group text-primary"></i>
            <span>Platform Games Volume & Revenue Matrix (11 Active Modules)</span>
        </h6>
        <span class="small text-muted">Aggregated live from database betting engines</span>
    </div>
    <div class="p-3">
        <div class="row g-3">
            <?php $__currentLoopData = $gamePerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $housePL = $g['total_wagered'] - $g['total_payout'];
                ?>
                <div class="col-sm-6 col-md-4 col-xl-3">
                    <div class="card border rounded-3 p-3 h-100 bg-light-subtle">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <div class="fw-bold text-dark d-flex align-items-center gap-2">
                                <div class="rounded-circle d-flex align-items-center justify-content-center text-white" style="width: 28px; height: 28px; background: <?php echo e($g['color']); ?>; font-size: 0.8rem;">
                                    <i class="fa-solid <?php echo e($g['icon']); ?>"></i>
                                </div>
                                <span><?php echo e($g['name']); ?></span>
                            </div>
                            <span class="badge bg-light text-muted border font-monospace"><?php echo e($g['total_bets']); ?> Bets</span>
                        </div>
                        
                        <div class="d-flex justify-content-between small text-muted mb-1">
                            <span>Turnover:</span>
                            <span class="fw-bold font-monospace text-dark">₹<?php echo e(number_format($g['total_wagered'], 2)); ?></span>
                        </div>
                        <div class="d-flex justify-content-between small text-muted mb-1">
                            <span>Payouts:</span>
                            <span class="fw-bold font-monospace text-success">₹<?php echo e(number_format($g['total_payout'], 2)); ?></span>
                        </div>
                        <div class="d-flex justify-content-between small border-top pt-1 mt-1">
                            <span class="fw-semibold">House Profit:</span>
                            <span class="fw-bold font-monospace <?php echo e($housePL >= 0 ? 'text-success' : 'text-danger'); ?>">
                                <?php echo e($housePL >= 0 ? '+' : ''); ?>₹<?php echo e(number_format($housePL, 2)); ?>

                            </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\rupeerush\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>